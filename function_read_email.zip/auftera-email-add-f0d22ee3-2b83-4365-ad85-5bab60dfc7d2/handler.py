import json
import urllib.parse
import boto3
import pymysql
import eml_parser
import datetime
import email
import bs4
import pybase64



rds_host  = "database-1.c2kbgonwhnk5.us-east-2.rds.amazonaws.com"
name = "admin"
password = "Ravi91068"
db_name = "auftera-crm"

conn = pymysql.connect(host=rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)


rds_host="database-1.ckv23lvefwmm.us-east-2.rds.amazonaws.com"
name="admin"
password="Ravi91068"
db_name="list_contacts"

list_conn = pymysql.connect(host=rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)


s3 = boto3.client('s3')


def json_serial(obj):
  if isinstance(obj, datetime.datetime):
      serial = obj.isoformat()
      return serial




def get_body_part_of_email(raw_email):
    b=email.message_from_string(raw_email.decode())

    body = ""


    for part in b.walk():
        ctype = part.get_content_type()
        cdispo = str(part.get('Content-Disposition'))



        body = part.get_payload(decode=True)

    return body

def final_list_name_from_low_name(dir_name):

    dict_for_name={"0_10k_big":"0_10K_big","10_20k_big":"10_20K_big","20k_30k_big":"20K_30K_big","30k_40k_big":"30K_40K_big","40k_big":"40K_Big"}
    return dict_for_name[dir_name]

def getCampDetFromUrl(to_email_arch):
    list_conn_curs = list_conn.cursor()

    get_email_comp=to_email_arch.split("@")[0].split("-")
    print(get_email_comp[0])
    if(get_email_comp[1]=="auftbnc"):

        main_ele_for_chg=get_email_comp[0].split("+");

        email_comp_main=pybase64.b64encode(main_ele_for_chg[1].encode('ascii')).decode("utf-8") ;



        print(email_comp_main)
        list_id=main_ele_for_chg[0]+"^"+email_comp_main
        con_id=main_ele_for_chg[2]



        update_query="update `"+list_id+"` set `arch`='1' where con_id='"+con_id+"'"

        print(update_query)
        list_conn_curs.execute(update_query)
        list_conn.commit()






def lambda_handler(event, context):
    data_file="test_email_file.eml";


    # Get the object from the event and show its content type


    try:

        f = open("../"+data_file, "r");
        email_body=f.read();



        ep = eml_parser.EmlParser()
        parsed_eml = ep.decode_email_bytes(email_body)


        to=parsed_eml['header']['to']
        email_from=parsed_eml['header']['from']
        print(email_from);

        if(email_from.split("@")[0]=="mailer-daemon" or email_from.split("@")[0]=="complaints"):

            to_email=to[0]

            getCampDetFromUrl(to_email)
            s3.delete_object(Bucket=bucket, Key=key)






        else:
            data_file=key
            mycursor = conn.cursor()


            sql = "INSERT INTO `recieve_email` (`to`, `file_det`,`from`) VALUES ('"+to[0]+"', '"+data_file+"','"+email_from+"')"


            mycursor.execute(sql)
            conn.commit()







        return response['ContentType']
    except Exception as e:
        print(e)
        print('Error getting object {} from bucket {}. Make sure they exist and your bucket is in the same region as this function.'.format(key, bucket))
        raise e
